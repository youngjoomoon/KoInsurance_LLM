# Databricks notebook source
!pip install openpyxl

# COMMAND ----------

import torch
if torch.cuda.is_available():
    device = torch.device("cuda")
    print('GPU is available.')
    print('We will use the GPU:', torch.cuda.get_device_name(0))

else:
    print("No GPU available, Using CPU Instead")
    device = torch.device("cpu")

# COMMAND ----------

# modules
import numpy as np
import pandas as pd
from sklearn import metrics 
from sklearn.model_selection import train_test_split
import transformers
from torch.utils.data import Dataset, DataLoader, RandomSampler, SequentialSampler 
from transformers import AutoTokenizer, AutoModel, ElectraTokenizer, ElectraModel ## version == 4.12.3
from sklearn.preprocessing import MultiLabelBinarizer

# COMMAND ----------

df = pd.read_excel('/Workspace/Shared/MYJ/03.OCR/Sugery_Classification/diagnosis_data_v3.xlsx').head(520)
#df = df[['의사소견 text', 'CSCCODE', 'CSCDESC']]
#df.columns = ['text', 's_code', 'desc']
df.head(3)

# COMMAND ----------

#수술 테이블
surg_db = pd.read_excel('/Workspace/Shared/MYJ/03.OCR/Sugery_Classification/대표수술코드.xlsx', sheet_name='Reference Table')
surg_db = surg_db[['수술코드', '수술명', '대표코드']]

# COMMAND ----------

df_merge = pd.merge(df, surg_db, how='left', left_on = 'SURGICAL_CD1', right_on='수술코드')

# COMMAND ----------

df_merge = df_merge.groupby(['IWNO', 'NOTE'], as_index=False).agg({'대표코드': ','.join})
df_merge[df_merge['IWNO']==202401121621]

# COMMAND ----------

# 수술코드 라벨링 
y_data = df_merge['대표코드'].apply(lambda x: [xs for xs in x.split(',')])

mlb = MultiLabelBinarizer()
mlb.fit(y_data)
#print(mlb.classes_)
labels = mlb.classes_
y_data = mlb.transform(y_data)
#df_labels = mlb.

# COMMAND ----------

labels

# COMMAND ----------

df_merge[df_merge['IWNO']==202401121621]

# COMMAND ----------

# 라벨링 된 수술코드 Dataframe에 input
df_merge['target_list'] = ''
for i, row in temp.iterrows():
    label = list(y_data[i])
    df_merge.at[i, 'target_list'] = label

# COMMAND ----------

# /n 없애기
df_merge = df_merge.replace(r'\r+|\n+|\t+', ' ', regex=True)

# COMMAND ----------

print("data label shape ::: {}".format(np.array(y_data).shape))
print("\ncool..!!")

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Word Count
# Word Count
df_merge['word_count'] = df_merge['NOTE'].apply(lambda x: len(x.split()))
df_merge.hist('word_count', bins=30)

# COMMAND ----------

df_final = df_merge[['NOTE', 'target_list']].copy()
df_final.head()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# Sections of config 

max_len = 512
train_batch_size = 8
valid_batch_size = 8
epochs = 5
learning_rate = 1e-05
MODEL_NAME = "beomi/KcELECTRA-base" #
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

# COMMAND ----------

class CustomDataset(Dataset):
    def __init__(self, df, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.data = df 
        self.text = df['NOTE']
        self.targets = self.data.target_list
        self.max_len = max_len
    
    def __len__(self):
        return len(self.text)

    def __getitem__(self, index):
        text = str(self.text[index])
        text = " ".join(text.split())

        inputs = self.tokenizer.encode_plus(
            text,
            None,
            add_special_tokens=True,
            max_length =self.max_len,
            padding='max_length',
            return_token_type_ids=True,
            truncation=True
        )
        
        ids = inputs['input_ids']
        mask = inputs['attention_mask']
        token_type_ids = inputs['token_type_ids']

        return {
            'ids': torch.tensor(ids, dtype=torch.long).flatten(),
            'mask': torch.tensor(mask, dtype=torch.long).flatten(),
            'token_type_ids': torch.tensor(token_type_ids, dtype=torch.long),
            'targets': torch.FloatTensor(self.targets[index])
                }



# COMMAND ----------

train_size = 0.8
train_dataset = df_final.sample(frac= train_size, random_state=200)
valid_dataset = df_final.drop(train_dataset.index).reset_index(drop=True)
train_dataset = train_dataset.reset_index(drop=True)

print("Full Dataset: {}".format(df_final.shape))
print("Train Dataset: {}".format(train_dataset.shape))
print("Test Dataset: {}".format(train_dataset.shape))

training_set = CustomDataset(train_dataset, tokenizer, max_len)
validation_set = CustomDataset(valid_dataset, tokenizer, max_len)

# COMMAND ----------

train_params = {'batch_size' : train_batch_size,
                'shuffle': True,
                'num_workers': 0
                }
test_params = {'batch_size' : valid_batch_size,
                'shuffle': False,
                'num_workers': 0
                }
training_loader = DataLoader(training_set, **train_params)
validation_loader = DataLoader(validation_set, **test_params)

# COMMAND ----------



# COMMAND ----------

class electraClass(torch.nn.Module):
    def __init__(self, dim = len(labels)):
        super(electraClass, self).__init__()
        self.dim = dim
        self.l1 = AutoModel.from_pretrained(MODEL_NAME, return_dict=True)
        self.classifier = torch.nn.Linear(768, dim)
    
    def forward(self, ids, mask, token_type_ids):
        output_1 = self.l1(ids, attention_mask = mask, token_type_ids = token_type_ids)
        #print('size of output_1 :', output_1.shape)
        output_2 = output_1.last_hidden_state[:,0,:]
        #print('size of output_1 :', output_1)
        output = self.classifier(output_2)
        output = torch.sigmoid(output)

        torch.cuda.empty_cache()
        return output

model = electraClass()
model.to(device)

# COMMAND ----------

def loss_fn(outputs, targets):
    return torch.nn.BCELoss()(outputs, targets)
optimizer = torch.optim.Adam(params = model.parameters(), lr=learning_rate)

# COMMAND ----------

def load_ckp(checkpoint_fpath, model, optimizer):
    checkpoint = torch.load(checkpoint_fpath)
    model.load_state_dict(checkpoint['state_dict'])
    optimizer.load_state_dict(checkpoint['optimzer'])
    valid_loss_min = checkpoint['valid_loss_mis']
    return model, optimizer, checkpoint['epoch'], valid_loss_min.item()

# COMMAND ----------

import shutil, sys 
def save_ckp(state, is_best, checkpoint_path, best_model_path):
    f_path = checkpoint_path 
    torch.save(state, f_path)
    if is_best:
        best_fpath = best_model_path
        shutil.copyfile(f_path, best_fpath)

# COMMAND ----------

val_targets = []
val_outputs = []

# COMMAND ----------

def train_model(start_epochs,  n_epochs, valid_loss_min_input, 
                training_loader, validation_loader, model, 
                optimizer, checkpoint_path, best_model_path):
   
  # initialize tracker for minimum validation loss
  valid_loss_min = valid_loss_min_input 
   
 
  for epoch in range(start_epochs, n_epochs+1):
    train_loss = 0
    valid_loss = 0

    model.train()
    print('############# Epoch {}: Training Start   #############'.format(epoch))
    for batch_idx, data in enumerate(training_loader):
        #print('yyy epoch', batch_idx)
        ids = data['ids'].to(device, dtype = torch.long)
        mask = data['mask'].to(device, dtype = torch.long)
        token_type_ids = data['token_type_ids'].to(device, dtype = torch.long)
        targets = data['targets'].to(device, dtype = torch.float)
        #print('ids size : ', ids.size())
        #print('mask size : ', mask.size())
        #print('token_type_ids size : ', token_type_ids.size())
        #print('targets size : ', targets.size())
        outputs = model(ids, mask, token_type_ids)
        #print('outputs size : ', outputs.size())
        optimizer.zero_grad()
        loss = loss_fn(outputs, targets)
        #if batch_idx%5000==0:
         #   print(f'Epoch: {epoch}, Training Loss:  {loss.item()}')
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        #print('before loss data in training', loss.item(), train_loss)
        train_loss = train_loss + ((1 / (batch_idx + 1)) * (loss.item() - train_loss))
        #print('after loss data in training', loss.item(), train_loss)
    
    print('############# Epoch {}: Training End     #############'.format(epoch))
    print('############# Epoch {}: Validation Start   #############'.format(epoch))
    ######################    
    # validate the model #
    ######################
 
    model.eval()
   
    with torch.no_grad():
      for batch_idx, data in enumerate(validation_loader, 0):
            ids = data['ids'].to(device, dtype = torch.long)
            mask = data['mask'].to(device, dtype = torch.long)
            token_type_ids = data['token_type_ids'].to(device, dtype = torch.long)
            targets = data['targets'].to(device, dtype = torch.float)
            outputs = model(ids, mask, token_type_ids)

            loss = loss_fn(outputs, targets)
            valid_loss = valid_loss + ((1 / (batch_idx + 1)) * (loss.item() - valid_loss))
            val_targets.extend(targets.cpu().detach().numpy().tolist())
            val_outputs.extend(torch.sigmoid(outputs).cpu().detach().numpy().tolist())

      print('############# Epoch {}: Validation End     #############'.format(epoch))
      # calculate average losses
      #print('before cal avg train loss', train_loss)
      train_loss = train_loss/len(training_loader)
      valid_loss = valid_loss/len(validation_loader)
      # print training/validation statistics 
      print('Epoch: {} \tAvgerage Training Loss: {:.6f} \tAverage Validation Loss: {:.6f}'.format(
            epoch, 
            train_loss,
            valid_loss
            ))
      
      # create checkpoint variable and add important data
      checkpoint = {
            'epoch': epoch + 1,
            'valid_loss_min': valid_loss,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict()
      }
        
        # save checkpoint
      save_ckp(checkpoint, False, checkpoint_path, best_model_path)
        
      ## TODO: save the model if validation loss has decreased
      if valid_loss <= valid_loss_min:
        print('Validation loss decreased ({:.6f} --> {:.6f}).  Saving model ...'.format(valid_loss_min,valid_loss))
        # save checkpoint as best model
        save_ckp(checkpoint, True, checkpoint_path, best_model_path)
        valid_loss_min = valid_loss

    print('############# Epoch {}  Done   #############\n'.format(epoch))


  return model



# COMMAND ----------

checkpoint_path = '/databricks/driver/azure/check.pt'
best_model = '/databricks/driver/azure/best_model.pt'
trained_model = train_model(1, 10, np.Inf, training_loader, validation_loader, model, 
                      optimizer,checkpoint_path,best_model)

# COMMAND ----------

# DBTITLE 1,Evaluation
val_preds = (np.array(val_outputs) > 0.5).astype(int)
accuracy = metrics.accuracy_score(val_targets, val_preds)
f1_score_micro = metrics.accuracy_score(val_targets, val_preds)
f1_score_macro = metrics.accuracy_score(val_targets, val_preds)
print(f"accuracy = {accuracy}")
print(f"f1_score_micro = {f1_score_micro}")
print(f"f1_score_macro = {f1_score_macro}")

# COMMAND ----------

from sklearn.metrics import multilabel_confusion_matrix as mcm, classification_report

# COMMAND ----------

print(classification_report(val_targets, val_preds))

# COMMAND ----------

from glob import glob
dir = '/databricks/driver/azure/'
best_ckpt = dir + 'best_model.pt' #'*.ckpt')[-1]
best_ckpt

# COMMAND ----------

model = electraClass()
model.load_state_dict(torch.load(best_ckpt)['state_dict'])
model.eval()

# COMMAND ----------

LABELS = list(labels)
THRESHOLD = 0.3

sample_text = '''
OP:2023.10.19#36,37치조골이식수술을동반하여임플란트식립을하였습니다시행하였음.119-91-94116초이스플란트치과의원서울시관악구신림로351(신림동,3층)보건업4.치료내용최금혁초이스플란트치과의원서울시관악구신림로351(신림동,3층)치과의원보건업 HP:
 '''
encoding = tokenizer.encode_plus(
    sample_text,
    None,
    add_special_tokens=True,
    max_length =512,
    padding='max_length',
    return_token_type_ids=True,
    return_tensors="pt"
    #truncation=True
            )
ids = encoding['input_ids']
mask = encoding['attention_mask']
token_type_ids = encoding['token_type_ids']

'''
#THRESHOLD = 0.3 넘는 모든 항목들 print  
with torch.no_grad():
    predictions = model(ids, mask, token_type_ids)
    predictions = predictions.flatten().numpy()
    for l,p in zip(LABELS, predictions):
        print(l, p)
        if p < THRESHOLD:
            continue
        print(f"{l}: {p}")
'''
# 가장 높은 수술코드 갖고 오기
with torch.no_grad(): 
    predictions = model(ids, mask, token_type_ids)
    predictions = predictions.flatten().numpy()
    p = predictions[predictions.argmax()]
    l = LABELS[predictions.argmax()]
    print(f"{l}: {p}")


# COMMAND ----------

LABELS

# COMMAND ----------


