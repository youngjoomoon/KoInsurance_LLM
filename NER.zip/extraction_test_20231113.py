# Databricks notebook source
pip install openpyxl

# COMMAND ----------

from transformers import ElectraTokenizer, ElectraForTokenClassification
from ner_pipeline_v3 import ner_scoring
from pprint import pprint
import pandas as pd 
import re 

tokenizer = ElectraTokenizer.from_pretrained("monologg/koelectra-small-v3-discriminator")
model = ElectraForTokenClassification.from_pretrained("/Workspace/Shared/MYJ/03.OCR/KoELECTRA-master/koelectra-small-naver-ner-ckpt/checkpoint-480")

ner = ner_scoring(model=model,
                  tokenizer=tokenizer,
                  ignore_labels=[], #['O''RELE', 'HOSP', 'FROM_TO'],
                  ignore_special_tokens=True)

# COMMAND ----------

import datetime as dt
date_formats = [r'\d{4}년\d{1,2}월\d{1,2}일',
                r'\d{1,2}월\d{1,2}일',
                r'\d{1,4}/\d{1,2}/\d{1,2}',
                r'\d{1,2}/\d{1,2}',
                r'\d{1,4}.\d{1,2}.\d{1,2}',
                r'\d{1}.\d{1}'
]
current_year = None 
current_month = None
month_day = ['월', '일']
def spacing(text, current_year = None, current_month=None):
    final_text = []
    text = re.sub('(\d+(\.\d+)?)', r' \1 ', text).strip() # 띄어쓰기
    text = ' '.join(text.split())
    text = re.sub(r'(\d{1,4})\s+\.\s+(\d{1,4})\s+\.\s+(\d{1,4})', r'\1.\2.\3', text) # . 사이 띄어쓰기 제거
    text = re.sub(r'(\d{1,4})\.(\d{1,4})\s+\.\s+(\d{1,4})', r'\1.\2.\3', text) # . 사이 띄어쓰기 제거 (뒤에만 띄어쓰기 있을 경우)
    text = re.sub(r'(\d{1,4})\s+\/\s+(\d{1,4})\s+\/\s+(\d{1,4})', r'\1.\2.\3', text) # / 사이 띄어쓰기 제거
    text = re.sub(r'(\d{1,4})\s+\-\s+(\d{1,4})\s+\-\s+(\d{1,4})', r'\1.\2.\3', text) # - 사이 띄어쓰기 제거
    text = re.sub(r'(\d{1,4})\s+\년\s+(\d{1,4})\s+\월\s+(\d{1,4})\s+\일', r'\1.\2.\3', text) # 년월일 사이 띄어쓰기 제거
    text = re.sub(r'(\d{1,4})\s+\월\s+(\d{1,4})\s+\일', r'\1.\2', text) # 월 일 만 있는 부분 사이 띄어쓰기 제거
    text = text.replace('~', ' ~ ')
    text = text.replace(',', ' , ')
    text = text.replace('(', ' ( ').replace(')', ' ) ')
    text = text.replace('에서','').replace('으로','').replace('에','').replace('을','').replace('로','').replace('를','').replace('까지','').replace('부터',' 부터').replace('"', '').replace("'", '').replace('동년동월', '동년 동월') #불용어 제거 및 띄어쓰기
    #text = text.replace('년', '년 ').replace('월', '월 ').replace('일', '일 ')
    #text = text.replace('  ', ' ')
    for word in text.split():
        if  ('년' in word) & (len(re.sub(r'[^0-9]', '', word))==2):
            word = '20' + re.sub(r'[^0-9]', '', word) + '년' #숫자 + 년  
        elif any (date_word in word for date_word in month_day) & (len(re.sub(r'[^0-9]', '', word))==1):
            str_date = re.sub(r'[0-9]', '', word)
            word = re.sub(r'[^0-9]', '', word).zfill(2) + str_date
        elif (len(re.sub(r'[^0-9]', '', word))==1): 
            word = re.sub(r'[^0-9]', '', word).zfill(2)

        ### yyyy.mm.dd 형태 전처리 ###
        if ('.' in word) & (any (re.match(date_format, word) for date_format in date_formats)) :
            split_date_final = []
            only_int = []
            split_date = word.split('.')
            idx = 0
            for date in split_date:
                if date != '0':   # 앞에 0일 경우에는 시간이 아님
                    date =  re.sub(r'[^0-9]', '', date).zfill(2)
                only_int += [date]
                if idx < len(split_date) - 1:
                    split_date_final += [date + '.']
                else: 
                    split_date_final += [date]
                idx += 1 
            if len(''.join(only_int)) == 6:
                word = '20' + ''.join(split_date_final)
                current_year = word[:4]
                current_month = only_int[4:6]
                current_day = only_int[6:8]
            else: word = ''.join(split_date_final)
            only_int = ''.join(only_int)
            if len(only_int)== 8:
                current_year = only_int[:4]
                current_month = only_int[4:6]
                current_day = only_int[6:8]
            try:
                if len(only_int)==4:
                    word = current_year + '.' + word
            except:
                pass
            #if current_year == None:
               #current_year = re.sub(r'[^0-9]', '', word)[:4] + ' .'
            #if current_month == None:
                #current_month = re.sub(r'[^0-9]', '', word)[4:6] + ' .'
        #동년 동월 처리 
        if (current_year == None) & ('년' in word): 
            current_year = word
        if (current_month == None) & ('월' in word): 
            current_month = word
        if ('다음날' in word):
            word = current_year + '.' + current_month +  '.' + current_day
            word = dt.datetime.strptime(word, '%Y.%m.%d') + dt.timedelta(days=1)
            word = dt.datetime.strftime(word, '%Y.%m.%d')
        final_text += [word]
        #print(only_int)

    final_text = ' '.join(final_text)
    final_text = re.sub(r'(\d{1,4})\s+\.\s+(\d{1,4})\s+\.\s+(\d{1,4})', r'\1.\2.\3', final_text) # . 사이 띄어쓰기 제거 (동년 동월에 대한 띄어쓰기 제거)
    final_text = re.sub(r'(\d{1,4})\s+\.\s+(\d{1,4})\.(\d{1,4})', r'\1.\2.\3', final_text) # . 사이 띄어쓰기 제거 (동월에 대한 띄어쓰기 제거)
    return final_text

# COMMAND ----------

path =  '/Workspace/Shared/MYJ/03.OCR'
df = pd.read_excel(path + '/sample_data.xlsx')

# COMMAND ----------

df_extraction = pd.DataFrame(columns=['진단내용', '입원일', '퇴원일', '수술일', '수술명'])
for row in df.itertuples():
    date_h_list, date_r_list, date_s_list, name_s_list = ner.extraction(spacing(row.text))
    row_to_append = pd.Series([row.text, date_h_list, date_r_list, date_s_list, name_s_list], index = df_extraction.columns)
    df_extraction = df_extraction.append(row_to_append, ignore_index=True)

# COMMAND ----------

df_extraction.iloc[17]['진단내용']

# COMMAND ----------

df_extraction.to_excel(path + '/sample_data_label.xlsx')

# COMMAND ----------

ner.extraction_to_print(spacing('상기환자는 2022년 3월 21일 본원 내원하여 상기병명으로 진단 후 2022년 3월 21일 (좌안), 3월 22일 (우안) 백내장초음파 유화술 및 후방 다초점 인공수정체 삽입술을 본원에서 시행받았음. 단초점렌즈 사용 시 조절장애의 치료효과를 기대하기 어려워 다초점 인공수정체를 사용하였음. 상기 수술 및 치료재료대는 백내장 치료목적이며, 향후 경과관찰 요함 '))

# COMMAND ----------

ner.extraction_to_print(spacing('[입원일자]: 2023-05-04 ~ 2023-05-07  [수술일자] : 2023-05-04 / [수술명] : 복강경하 자궁근종 절제술 + 자국내막 소파술   [산부인과/외래] 2023-05-12  [산부인과/외래] 2023-04-28   [산부인과/외래] 2023-04-26'))

# COMMAND ----------


